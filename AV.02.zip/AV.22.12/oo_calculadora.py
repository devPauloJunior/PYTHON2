#Lembrando que:
# snake_case para variáveis, funções e métodos;
# PascalCase para classes;
#============================================================
# Crie um ambiente O.O. completo utilizando classes e métodos:
# utilizar as classes CalculadoraMM(Super), Adicao, Subtracao, Multiplicacao, Divisao e Equacao para elas faça:
# faça herança quando julgar necessária
# sua calculadora deve trabalha com strings validando as operações Ex: "2+2" "16*140" "2x-10=9"
# crie os padrões e faça as validações
# utilize as expressões regulares para as validações
# OBS: Veja a possibilidade de utilizar os métodos mágicos
# OBS: Faça todas as validações
# OBS: Fique atento aos impedimentos dos métodos
# OBS: Faça as impressões necessárias
